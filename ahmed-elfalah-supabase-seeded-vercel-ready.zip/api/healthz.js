import crypto from "node:crypto";

export default function handler(req, res) {
  return res.status(200).json({ status: "ok" });
}
